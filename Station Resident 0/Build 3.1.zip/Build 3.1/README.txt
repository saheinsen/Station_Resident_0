Station Resident 0 Build ver 3.1
By Stefan Heinsen 5-13-15
Made in unity 4.5.5

When opening in editor there is no need to use openGL
Resolution is already programmed in.

Works on other computers


Features
Zero G Jetpack Movement

Atmospheric soundtrack.

Discover the fate of an abandoned space station.