Station Resident 0 Build ver 2.0
By Stefan Heinsen 5-12-15
Made in unity 4.5.5

When opening in editor there is no need to use openGL


